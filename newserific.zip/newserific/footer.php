<!-- ####################################################################################################### -->
<div class="wrapper col6">
  <div id="footer">
    
      
      <?php dynamic_sidebar( 'footer-sidebar' ); ?>
    
    
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
    <div class="wrapper col7">
      <div id="copyright">
        <p class="fl_left"><?php global $newserrific; echo $newserrific['copyright-text']; ?></p>
        <p class="fl_right">Template by <a target="_blank" href="http://www.os-templates.com/" title="Free Website Templates">OS Templates</a></p>
        <br class="clear" />
      </div>
    </div>

    <?php wp_footer(); ?>
</body>
</html>