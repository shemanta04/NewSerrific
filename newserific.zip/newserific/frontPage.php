<?php get_header(); ?>

<?php
    /*
        Template Name: Homepage Template
    */
?>

<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <div id="featured_post">
          <!-- featured posts -->
          <?php
              $post_content = new WP_Query( [
                  'post_type'         => 'post',
                  'cat'               => '3',
                  'posts_per_page'    => 1
              ] );
          ?>

          <?php while( $post_content->have_posts() ) : $post_content->the_post(); ?>
              <a href="<?php the_permalink();?>"><?php the_post_thumbnail(); ?></a>
              <h2 style="margin-top: 20px;"><b><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></b></h2>
              <p><?php read_more(49); ?></p>
              <a href="<?php the_permalink(); ?>">Continue reading...</a>
          <?php endwhile; ?>

      </div>
      <div id="hpage_latest">
        <!-- latest posts -->
        <ul>
          
            <?php 

                $post_content = new WP_Query( [
                    'post_type' => 'post',
                    'category_name'   => 'latest_posts',
                    'posts_per_page'  => 3
                ] );

            ?>

            <?php while( $post_content->have_posts() ) : $post_content->the_post(); ?>

              <li>
                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                <p style="font-weight: bold;"><?php the_title(); ?></p>
                <p><?php read_more(20); ?></p>
                <p class="readmore"><a href="<?php the_permalink(); ?>">Continue Reading &raquo;</a></p>
              </li>
            
            <?php endwhile; ?>

        </ul>
        <br class="clear" />
      </div>
    </div>

    <!-- sidebars -->
    <?php get_sidebar(); ?>


<!-- ############################### Gallery ################################# -->

<div class="wrapper col5">
  <div class="gallery">

      <?php 
          $gallery = new WP_Query( [
              'post_type'       => 'gallery',
              'posts_per_page'  => 8,
          ] )

      ?>

    <!-- <h2>gallery photos</h2> -->
    <ul>
        <h2>Gallery Photos</h2>
        <?php while( $gallery->have_posts() ) : $gallery->the_post(); ?>
            <li>
                <a href="#"><?php the_post_thumbnail(); ?></a>
            </li>
        <?php endwhile; ?>
    </ul>
    <br class="clear" />
  </div>
</div>

<?php get_footer(); ?>