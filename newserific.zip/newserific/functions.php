<?php

	function newserrific_options() {

		// theme supports
		add_theme_support( 'title-tag' );
		add_theme_support( 'custom-header' );
		add_theme_support( 'custom-background' );
		add_theme_support( 'post-thumbnails' );


		// menu register
		register_nav_menus( [
			'primary-menu'	=> 'Primary Menu'
		] );


		// read more button
		function read_more($limit) {
			$post_contentsss = explode( ' ', get_the_content() );
			$less_contentsss = array_slice( $post_contentsss, 0, $limit );
			echo implode( ' ' , $less_contentsss );
		}


		// sidebar registration
		function sidebars() {

			// Right sidebar
			// Homepage sidebar
			register_sidebar( [
				'name'			=> 'Right Sidebar',
				'description'	=> 'This is homepage right sidebar',
				'id'			=> 'right-sidebar',
				'before_widget'	=> '<ul id="latestnews">',
				'after_widget'	=> '</ul>',
				'before_title'	=> '<li>',
				'after_title'	=> '</li>'
			] );

			// footer sidebars
			register_sidebar( [
				'name'			=>	'Footer Sidebar',
				'description'	=>	'This is global footer sidebars',
				'id'			=>	'footer-sidebar',
				'before_title'	=>	'<h2>',
				'after_title'	=>	'</h2><ul>',
				'before_widget'	=>	'<div class="footbox twitter">',
				'after_widget'	=>	'</ul></div>'
			] );	
					

		}
		add_action( 'widgets_init', 'sidebars' );
		


		// gallery register
		register_post_type( '$gallery', [
			'labels'					=>	[
				'name'					=>	'Gallery',
				'add_new_item'			=>	'Add New Photo',
				'edit_item'				=>	'Edit Photo',
				'featured_image'		=>	'new new newnnew',
				'set_featured_image'	=>	'Add new gallrey image',
				'remove_featured_image'	=>	'Remove this image',
			],
			'public'	=> true,
			'supports'	=> [ 'title', 'thumbnail' ],
			'menu_icon'				=>	'dashicons-format-gallery',
		] );


		include_once( 'lib/ReduxCore/framework.php' );
		include_once( 'lib/sample/config.php' );


	}
	add_action( 'after_setup_theme', 'newserrific_options' );

