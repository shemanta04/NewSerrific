<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/layout/styles/layout.css" type="text/css" />
    <?php wp_head(); ?>
    <link rel="icon" href="<?php global $newserrific; echo $newserrific['favicon']; ?>" type="image/gif" sizes="16x16">
</head>
<body id="top" <?php body_class(); ?> >
<div class="wrapper col1">
  <div id="header">
    <div class="fl_left">
      <h1><a href="<?php bloginfo( 'home' ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
      <p><?php bloginfo( 'description' ); ?></p>
    </div>
    <div class="fl_right"><a href="#"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/demo/468x60.gif" alt="" /></a></div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="topbar">
    <div id="topnav">
      <ul>
        <?php
            // primary menu
            wp_nav_menu( 'primary-menu' );

         ?>
      </ul>
    </div>
    <div id="search">
      <form action="<?php bloginfo( 'home' ); ?>" method="GET">
          <input name="s" type="text" value="Search Our Website&hellip;"  onfocus="this.value=(this.value=='Search Our Website&hellip;')? '' : this.value ;" />
          <input type="submit" name="go" id="go" value="Search" />
      </form>
    </div>
    <br class="clear" />
  </div>
</div>