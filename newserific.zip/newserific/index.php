<?php get_header(); ?>

<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <div id="hpage_latest">
        <!-- latest posts -->
          <ul>
              <?php 
                  $post_content = new WP_Query( [
                      'post_type' => 'post',
                      'posts_per_page'  => 7,
                  ] );
              ?>
              
            <?php while( $post_content->have_posts() ) : $post_content->the_post(); ?>

              <li style="width: 97%;">
                <a href="<?php the_permalink();?>"><?php the_post_thumbnail(); ?></a>
                <p style="font-weight: bold;"><?php the_title(); ?></p>
                <p><?php read_more(49); ?></p>
                <p class="readmore"><a href="<?php the_permalink(); ?>">Continue Reading &raquo;</a></p>
              </li>
            
            <?php endwhile; ?>

        </ul>
        <br class="clear" />
      </div>
    </div>

    <!-- sidebars -->
    <?php get_sidebar(); ?>


<?php get_footer(); ?>