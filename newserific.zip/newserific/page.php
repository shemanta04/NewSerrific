<?php get_header(); ?>

<!-- ####################################################################################################### -->
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      
        <?php while( have_posts() ) : the_post(); ?>
            <h2><?php the_title(); ?></h2>
            <?php the_post_thumbnail(); ?>
            <p><?php the_content(); ?></p>

            <?php comments_template(); ?>

        <?php endwhile; ?>

    </div>

    <!-- sidebars -->
    <?php get_sidebar(); ?>


<?php get_footer(); ?>