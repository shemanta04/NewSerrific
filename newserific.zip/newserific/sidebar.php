<!-- sidebars -->

    <div id="column">
     
      <?php dynamic_sidebar( 'right-sidebar' ); ?> 

    </div>
    <br class="clear" />
  </div>
  <br class="clear" />
</div>